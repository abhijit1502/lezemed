const ApiConfig = {
    baseUrl: "https://eremitly.com/pilot/api",
};
export default ApiConfig;
